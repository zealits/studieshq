to setup this project on local 
git clone "https://github.com/zealits/studieshq.git"
then npm install
then cd ./frontend
then npm install
open two seperate terminal
in one do npm run dev
and in one cd ./frontend npm start
